package com.xh.bbs.filter;

public class ServletException extends Exception {

}
