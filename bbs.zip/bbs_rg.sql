/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 80025
Source Host           : localhost:3306
Source Database       : bbs_rg

Target Server Type    : MYSQL
Target Server Version : 80025
File Encoding         : 65001

Date: 2021-06-08 11:10:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for forum_info
-- ----------------------------
DROP TABLE IF EXISTS `forum_info`;
CREATE TABLE `forum_info` (
  `fid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `create_time` datetime NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of forum_info
-- ----------------------------
INSERT INTO `forum_info` VALUES ('55', '什么是背包问题？', '背包问题可以用什么算法实现', '2022-06-18 15:52:51', '11');
INSERT INTO `forum_info` VALUES ('57', '遗传算法求解背包问题', '遗传算法求解背包问题是不是更加简单', '2022-06-19 10:57:04', '2018961');

-- ----------------------------
-- Table structure for reply_info
-- ----------------------------
DROP TABLE IF EXISTS `reply_info`;
CREATE TABLE `reply_info` (
  `reply_id` int NOT NULL AUTO_INCREMENT,
  `reply_content` varchar(255) NOT NULL,
  `reply_time` datetime NOT NULL,
  `user_id` int NOT NULL,
  `fid` int NOT NULL,
  PRIMARY KEY (`reply_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of reply_info
-- ----------------------------
INSERT INTO `reply_info` VALUES ('54', '在我这里', '2021-05-21 11:00:06', '28', '57');

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_sex` varchar(2) NOT NULL,
  `user_face` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_from` varchar(200) NOT NULL,
  `isAdmin` int DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES ('11', '11', '6512bd43d9caa6e02c990b0a82652dca', '男', '/images/userface/user01.jpg', '11', '1111@qq.com', '11', null);
INSERT INTO `user_info` VALUES ('28', '281', 'e10adc3949ba59abbe56e057f20f883e', '女', '/images/userface/user04.jpg', '2435764', '297865@qq.com', '陕西宝鸡', '1');
INSERT INTO `user_info` VALUES ('2018961', '王卫', 'e10adc3949ba59abbe56e057f20f883e', '男', 'images/userface/user11.jpg', '150391', '4365465443@qq.com', '陕西宝鸡', null);
